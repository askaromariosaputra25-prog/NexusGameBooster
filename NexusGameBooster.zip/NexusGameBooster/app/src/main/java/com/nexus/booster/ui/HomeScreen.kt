package com.nexus.booster.ui

import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nexus.booster.boost.BoostOrchestrator
import com.nexus.booster.boost.BoostReport
import com.nexus.booster.boost.GameTarget
import com.nexus.booster.boost.PingBooster
import com.nexus.booster.oem.OemAutoStartHelper
import com.nexus.booster.overlay.GameDashboardService
import com.nexus.booster.shell.ShizukuHelper
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

private val Gold = Color(0xFFFFD700)
private val DarkBg = Color(0xFF0B0B0B)
private val CardBg = Color(0xFF161616)

private fun isInstalled(ctx: Context, pkg: String): Boolean = try {
    ctx.packageManager.getPackageInfo(pkg, 0)
    true
} catch (_: PackageManager.NameNotFoundException) {
    false
}

private fun lastPlayed(ctx: Context, pkg: String): String {
    val usm = ctx.getSystemService(UsageStatsManager::class.java)
    val now = System.currentTimeMillis()
    val t = usm.queryAndAggregateUsageStats(now - 30L * 86_400_000L, now)[pkg]?.lastTimeUsed
        ?: return "Belum ada data"
    val mins = (now - t) / 60_000
    return when {
        mins < 60 -> "$mins menit lalu"
        mins < 1440 -> "${mins / 60} jam lalu"
        else -> "${mins / 1440} hari lalu"
    }
}

private fun playStoreIntent(pkg: String) =
    Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$pkg"))

@Composable
fun HomeScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()

    var installed by remember { mutableStateOf<Map<GameTarget, Boolean>>(emptyMap()) }
    var lastPlayedMap by remember { mutableStateOf<Map<GameTarget, String>>(emptyMap()) }
    var pings by remember { mutableStateOf<Map<GameTarget, Double?>>(emptyMap()) }
    var selected by remember { mutableStateOf(GameTarget.MLBB) }
    var shizuku by remember { mutableStateOf(false) }
    var usageOk by remember { mutableStateOf(false) }
    var overlayOk by remember { mutableStateOf(false) }
    var step by remember { mutableStateOf<String?>(null) }
    var report by remember { mutableStateOf<BoostReport?>(null) }

    LaunchedEffect(Unit) {
        while (true) {
            installed = GameTarget.entries.associateWith { g -> g.packages.any { isInstalled(ctx, it) } }
            lastPlayedMap = GameTarget.entries.associateWith { g ->
                g.packages.firstOrNull { isInstalled(ctx, it) }?.let { lastPlayed(ctx, it) } ?: "-"
            }
            shizuku = ShizukuHelper.hasPermission()
            usageOk = OemAutoStartHelper.hasUsageAccess(ctx)
            overlayOk = Settings.canDrawOverlays(ctx)
            pings = GameTarget.entries.associateWith { PingBooster.measurePing(it.serverHost) }
            delay(5_000)
        }
    }

    val pulse = rememberInfiniteTransition(label = "pulse")
    val pulseScale by pulse.animateFloat(
        initialValue = 1f,
        targetValue = 1.06f,
        animationSpec = infiniteRepeatable(tween(900), RepeatMode.Reverse),
        label = "pulseScale",
    )

    Box(Modifier.fillMaxSize().background(DarkBg)) {
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text("NEXUS GAME BOOSTER", color = Gold, fontSize = 26.sp, fontWeight = FontWeight.Black)
            Text("MLBB • Free Fire • PUBG Anti-Lag", color = Color.Gray, fontSize = 13.sp)

            if (!usageOk || !overlayOk) {
                Card(colors = CardDefaults.cardColors(containerColor = CardBg)) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Biar gak lag, izinkan akses ini dulu", color = Gold, fontWeight = FontWeight.Bold)
                        if (!usageOk) OutlinedButton(onClick = { ctx.startActivity(OemAutoStartHelper.usageAccessIntent()) }) {
                            Text("Izinkan Usage Access")
                        }
                        if (!overlayOk) OutlinedButton(onClick = { ctx.startActivity(OemAutoStartHelper.overlayIntent(ctx)) }) {
                            Text("Izinkan Tampil di Atas Aplikasi")
                        }
                        OutlinedButton(onClick = { OemAutoStartHelper.openAutoStart(ctx) }) {
                            Text("Buka Pengaturan Autostart HP")
                        }
                    }
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    if (shizuku) "● Shizuku aktif (boost penuh)" else "● Shizuku belum aktif (mode terbatas)",
                    color = if (shizuku) Color.Green else Color.Red,
                    modifier = Modifier.weight(1f),
                )
                if (!shizuku) TextButton(onClick = { ShizukuHelper.requestPermission() }) { Text("Aktifkan") }
            }

            GameTarget.entries.forEach { g ->
                val ok = installed[g] == true
                val isSel = selected == g
                Card(
                    onClick = { if (ok) selected = g },
                    modifier = Modifier.fillMaxWidth().alpha(if (ok) 1f else 0.4f),
                    colors = CardDefaults.cardColors(containerColor = CardBg),
                    border = if (isSel) BorderStroke(2.dp, Color(g.accentArgb)) else null,
                ) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(g.title, color = Color(g.accentArgb), fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text("Terakhir main: ${lastPlayedMap[g] ?: "-"}", color = Color.LightGray, fontSize = 12.sp)
                        Text(
                            "Ping server: ${pings[g]?.let { "${it.roundToInt()} ms" } ?: "--"}",
                            color = Color.White, fontSize = 12.sp,
                        )
                        if (!ok) {
                            Button(onClick = { ctx.startActivity(playStoreIntent(g.packages.first())) }) {
                                Text("Install")
                            }
                        }
                    }
                }
            }

            Spacer(Modifier.height(8.dp))
            Button(
                onClick = {
                    scope.launch {
                        report = null
                        val pkgs = selected.packages.filter { isInstalled(ctx, it) }
                        val rep = BoostOrchestrator.boostAndPrepare(ctx, selected, pkgs) { step = it }
                        pkgs.firstNotNullOfOrNull { ctx.packageManager.getLaunchIntentForPackage(it) }
                            ?.let { ctx.startActivity(it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                        if (overlayOk && usageOk) GameDashboardService.start(ctx, selected)
                        step = null
                        report = rep
                    }
                },
                enabled = installed[selected] == true && step == null,
                modifier = Modifier.fillMaxWidth().height(64.dp).scale(pulseScale),
                colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Color.Black),
            ) {
                Text("SUPER BOOST & PLAY", fontWeight = FontWeight.Black, fontSize = 18.sp)
            }

            report?.let { r ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = CardBg),
                    border = BorderStroke(1.dp, Gold),
                ) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Device is Ready for Rank Push!", color = Gold, fontWeight = FontWeight.Black, fontSize = 18.sp)
                        Text("RAM dibebaskan: ${r.freedMb} MB • Mode: ${r.mode}", color = Color.White)
                        Text(
                            "Ping: ${r.pingBefore?.roundToInt() ?: "--"} ms → ${r.pingAfter?.roundToInt() ?: "--"} ms",
                            color = Color.White,
                        )
                        r.notes.forEach { Text(it, color = Color.LightGray, fontSize = 12.sp) }
                    }
                }
            }
        }

        step?.let { msg ->
            Box(
                Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.92f)),
                contentAlignment = Alignment.Center,
            ) {
                Text(msg, color = Gold, fontSize = 22.sp, fontWeight = FontWeight.Black)
            }
        }
    }
}
