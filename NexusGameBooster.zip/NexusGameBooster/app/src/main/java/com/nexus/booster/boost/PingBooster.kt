package com.nexus.booster.boost

import com.nexus.booster.shell.ShellExecutor
import com.nexus.booster.shell.ShizukuHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.TimeUnit

object PingBooster {
    data class Result(val before: Double?, val after: Double?, val notes: List<String>)

    private val NETWORK_HOGS = listOf(
        "com.facebook.katana", "com.facebook.orca", "com.instagram.android",
        "com.zhiliaoapp.musically", "com.ss.android.ugc.trill", "com.google.android.youtube",
    )
    private val TIME_REGEX = Regex("time[=<]([0-9.]+)\\s*ms")
    private var prevDnsMode: String? = null

    /** ICMP via Runtime.exec("ping"), with TCP-connect timing as fallback when ICMP is blocked. */
    suspend fun measurePing(host: String): Double? = withContext(Dispatchers.IO) {
        icmpPing(host) ?: tcpPing(host)
    }

    private fun icmpPing(host: String): Double? = try {
        val p = Runtime.getRuntime().exec(arrayOf("ping", "-c", "1", host))
        if (!p.waitFor(3, TimeUnit.SECONDS)) {
            p.destroy(); null
        } else {
            TIME_REGEX.find(p.inputStream.bufferedReader().readText())?.groupValues?.get(1)?.toDoubleOrNull()
        }
    } catch (_: Exception) { null }

    private fun tcpPing(host: String): Double? = try {
        val t0 = System.nanoTime()
        Socket().use { it.connect(InetSocketAddress(host, 443), 3_000) }
        (System.nanoTime() - t0) / 1_000_000.0
    } catch (_: Exception) { null }

    /** Applies network tweaks (needs Shizuku). Returns ping before/after for the UI. */
    suspend fun boost(gameHost: String): Result {
        val before = measurePing(gameHost)
        val notes = mutableListOf<String>()
        if (!ShizukuHelper.hasPermission()) {
            notes += "✗ Tweak jaringan butuh Shizuku aktif"
        } else {
            prevDnsMode = ShellExecutor.run("settings get global private_dns_mode").output
                .let { if (it.isBlank() || it == "null") "off" else it }
            ShellExecutor.runLogged("settings put global private_dns_mode hostname", "Private DNS aktif", notes)
            ShellExecutor.runLogged("settings put global private_dns_specifier one.one.one.one", "DNS Cloudflare (one.one.one.one)", notes)
            ShellExecutor.runLogged("ndc resolver flushdefaultif || true", "Flush DNS", notes)
            ShellExecutor.runLogged(
                NETWORK_HOGS.joinToString(";") { "am force-stop $it" },
                "Hentikan Facebook/IG/TikTok/YouTube", notes,
            )
            ShellExecutor.runLogged("settings put global auto_sync 0", "Auto-sync dimatikan", notes)
            ShellExecutor.runLogged("settings put global mobile_data_always_on 1", "Mobile data always-on", notes)
            ShellExecutor.runLogged("settings put global wifi_low_latency 1", "Wi-Fi low-latency (tergantung ROM)", notes)
        }
        return Result(before, measurePing(gameHost), notes)
    }

    /** Restores what we changed so the phone isn't left on a custom DNS. */
    suspend fun restore() {
        if (!ShizukuHelper.hasPermission()) return
        prevDnsMode?.let { ShellExecutor.run("settings put global private_dns_mode $it") }
        ShellExecutor.run("settings put global auto_sync 1")
    }
}
