package com.nexus.booster.overlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.IBinder
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.nexus.booster.boost.GameTarget
import com.nexus.booster.boost.PingBooster
import com.nexus.booster.boost.PreLaunchCleaner
import com.nexus.booster.shell.ShellExecutor
import com.nexus.booster.shell.ShizukuHelper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.cancelChildren
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.roundToInt

class GameDashboardService : Service() {

    companion object {
        private const val EXTRA_GAME = "game"
        private const val CHANNEL_ID = "nexus_dashboard"
        private const val NOTIF_ID = 42

        fun start(ctx: Context, game: GameTarget) {
            ctx.startForegroundService(
                Intent(ctx, GameDashboardService::class.java).putExtra(EXTRA_GAME, game.name)
            )
        }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private lateinit var game: GameTarget
    private lateinit var wm: WindowManager
    private lateinit var params: WindowManager.LayoutParams
    private lateinit var root: LinearLayout
    private lateinit var body: LinearLayout
    private lateinit var tvHeader: TextView
    private lateinit var tvFps: TextView
    private lateinit var tvRam: TextView
    private lateinit var tvPing: TextView
    private lateinit var tvTemp: TextView
    private lateinit var tvSummary: TextView

    private var overlayShown = false
    private var currentFg: String? = null
    private var seenGame = false
    private var missed = 0
    private var notifBlocked = false
    private val pings = mutableListOf<Double>()
    private val fpsSamples = mutableListOf<Double>()
    private var lastTotalFrames: Long? = null
    private var lastFrameTs = 0L
    private var lastFpsPkg: String? = null
    private var startedAt = 0L

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val name = intent?.getStringExtra(EXTRA_GAME) ?: return START_NOT_STICKY
        game = GameTarget.valueOf(name)
        createChannel()
        ServiceCompat.startForeground(
            this, NOTIF_ID, buildNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
        )
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (!overlayShown) {
            buildOverlay()
            startedAt = SystemClock.elapsedRealtime()
            startLoops()
        }
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        scope.cancel()
        if (overlayShown) runCatching { wm.removeView(root) }
        overlayShown = false
        super.onDestroy()
    }

    private fun buildOverlay() {
        wm = getSystemService(WindowManager::class.java)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.argb(210, 12, 12, 12))
            setPadding(24, 16, 24, 16)
        }
        tvHeader = label(game.title.uppercase(), game.accentArgb, 13f)
        tvSummary = label("", Color.WHITE, 12f).apply { visibility = View.GONE }
        tvFps = label("FPS: --", Color.WHITE)
        tvRam = label("RAM: --", Color.WHITE)
        tvPing = label("Ping: --", Color.WHITE)
        tvTemp = label("CPU Temp: --", Color.WHITE)

        body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        listOf(tvFps, tvRam, tvPing, tvTemp).forEach { body.addView(it) }

        val boostAgain = btn("Boost Again") {
            scope.launch {
                PingBooster.boost(game.serverHost)
                PreLaunchCleaner.clean(this@GameDashboardService)
                tvHeader.text = "BOOST ULANG ✓"
            }
        }
        val clearRam = btn("Clear RAM") {
            scope.launch {
                val r = PreLaunchCleaner.clean(this@GameDashboardService)
                tvHeader.text = "RAM +${r.freedMb} MB"
            }
        }
        body.addView(row(boostAgain, clearRam))

        val notif = btn("Block Notif: Off") { b ->
            scope.launch {
                notifBlocked = !notifBlocked
                ShellExecutor.run(if (notifBlocked) "cmd notification set_dnd priority" else "cmd notification set_dnd off")
                b.text = if (notifBlocked) "Block Notif: On" else "Block Notif: Off"
            }
        }
        val extra = if (game == GameTarget.MLBB) {
            btn("ML Turbo: On") { b ->
                b.text = if (b.text.toString().endsWith("On")) "ML Turbo: Off" else "ML Turbo: On"
            }
        } else {
            btn("Aim Stabilizer: Off") { b ->
                b.text = if (b.text.toString().endsWith("Off")) "Aim Stabilizer: On" else "Aim Stabilizer: Off"
            }
        }
        body.addView(row(notif, extra))

        // Hide sits outside the body so it stays reachable when the body is collapsed.
        val hide = btn("Hide") { b ->
            body.visibility = if (body.visibility == View.VISIBLE) View.GONE else View.VISIBLE
            b.text = if (body.visibility == View.VISIBLE) "Hide" else "Show"
        }
        root.addView(tvHeader)
        root.addView(row(hide))
        root.addView(tvSummary)
        root.addView(body)

        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 24
            y = 200
        }
        wm.addView(root, params)
        overlayShown = true

        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        tvHeader.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x; startY = params.y
                    touchX = e.rawX; touchY = e.rawY
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = startX + (e.rawX - touchX).toInt()
                    params.y = startY + (e.rawY - touchY).toInt()
                    wm.updateViewLayout(root, params)
                }
            }
            true
        }
    }

    private fun startLoops() {
        // Ping every 3 s to the game's server host
        scope.launch {
            while (isActive) {
                val p = PingBooster.measurePing(game.serverHost)
                p?.let { pings += it }
                tvPing.text = p?.let { "Ping: ${it.roundToInt()} ms" } ?: "Ping: --"
                delay(3_000)
            }
        }
        // RAM + CPU temp every 2 s
        scope.launch {
            while (isActive) {
                tvRam.text = "RAM: ${PreLaunchCleaner.memAvailMb(this@GameDashboardService)} MB Free"
                tvTemp.text = "CPU Temp: ${withContext(Dispatchers.IO) { readCpuTemp() }}"
                delay(2_000)
            }
        }
        // Foreground watcher + real game FPS every 1 s
        scope.launch {
            while (isActive) {
                val fg = withContext(Dispatchers.IO) { foregroundPkg() }
                if (fg != null) currentFg = fg
                val pkg = currentFg
                if (pkg != null && pkg in game.packages) {
                    seenGame = true
                    missed = 0
                    val fps = sampleFps(pkg)
                    if (fps != null) {
                        fpsSamples += fps
                        tvFps.text = "FPS: ${fps.roundToInt()}"
                    } else if (!ShizukuHelper.hasPermission()) {
                        tvFps.text = "FPS: butuh Shizuku"
                    }
                } else if (seenGame && ++missed >= 4) {
                    endSession()
                    break
                } else if (!seenGame && SystemClock.elapsedRealtime() - startedAt > 90_000) {
                    stopSelf()
                    break
                }
                delay(1_000)
            }
        }
    }

    /** Real per-game FPS: diff of "Total frames rendered" from dumpsys gfxinfo (needs Shizuku). */
    private suspend fun sampleFps(pkg: String): Double? {
        if (!ShizukuHelper.hasPermission()) return null
        if (pkg != lastFpsPkg) { lastTotalFrames = null; lastFpsPkg = pkg }
        val out = ShellExecutor.run("dumpsys gfxinfo $pkg").output
        val total = Regex("Total frames rendered:\\s*(\\d+)").find(out)
            ?.groupValues?.get(1)?.toLongOrNull() ?: return null
        val now = SystemClock.elapsedRealtime()
        val prev = lastTotalFrames
        val prevTs = lastFrameTs
        lastTotalFrames = total
        lastFrameTs = now
        if (prev == null || now <= prevTs) return null
        return ((total - prev).coerceAtLeast(0) * 1000.0) / (now - prevTs)
    }

    @Suppress("DEPRECATION")
    private fun foregroundPkg(): String? {
        val usm = getSystemService(UsageStatsManager::class.java) ?: return currentFg
        val now = System.currentTimeMillis()
        val events = usm.queryEvents(now - 60_000, now)
        val e = UsageEvents.Event()
        var last: String? = null
        while (events.hasNextEvent()) {
            events.getNextEvent(e)
            if (e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND) last = e.packageName
        }
        return last ?: currentFg
    }

    private fun readCpuTemp(): String {
        File("/sys/class/thermal").listFiles { f -> f.name.startsWith("thermal_zone") }?.forEach { z ->
            val type = runCatching { File(z, "type").readText().trim() }.getOrNull() ?: return@forEach
            if (type.contains("cpu", true) || type.contains("tsens", true)) {
                val raw = runCatching { File(z, "temp").readText().trim().toLong() }.getOrNull() ?: return@forEach
                return "${if (raw > 1000) raw / 1000 else raw}°C"
            }
        }
        return "N/A (diblokir sistem)"
    }

    private fun endSession() {
        scope.coroutineContext.cancelChildren()
        CoroutineScope(Dispatchers.IO).launch {
            if (notifBlocked) ShellExecutor.run("cmd notification set_dnd off")
            PingBooster.restore()
        }
        val mins = (SystemClock.elapsedRealtime() - startedAt) / 60_000
        val avgPing = if (pings.isEmpty()) "--" else pings.average().roundToInt().toString()
        // "Stable" = share of seconds with FPS >= 55
        val stable = if (fpsSamples.isEmpty()) "--"
        else "${fpsSamples.count { it >= 55 } * 100 / fpsSamples.size}%"
        tvHeader.text = "SESI SELESAI"
        body.visibility = View.GONE
        tvSummary.visibility = View.VISIBLE
        tvSummary.text = "Game Session: $mins min, Avg Ping ${avgPing}ms, FPS Stable $stable"
        scope.launch {
            delay(15_000)
            stopSelf()
        }
    }

    private fun createChannel() {
        getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Game Dashboard", NotificationManager.IMPORTANCE_LOW)
        )
    }

    private fun buildNotification(): Notification =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_info_details)
            .setContentTitle("NEXUS Game Dashboard aktif")
            .setContentText("Memantau ${game.title}")
            .setOngoing(true)
            .build()

    private fun label(text: String, color: Int, size: Float = 11f): TextView =
        TextView(this).apply {
            this.text = text
            setTextColor(color)
            textSize = size
        }

    private fun btn(label: String, onClick: (Button) -> Unit): Button =
        Button(this).apply {
            text = label
            isAllCaps = false
            textSize = 10f
            minHeight = 0
            minimumHeight = 0
            setOnClickListener { onClick(this) }
        }

    private fun row(vararg views: View): LinearLayout =
        LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            views.forEach { addView(it, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)) }
        }
}
