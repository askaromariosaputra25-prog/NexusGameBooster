package com.nexus.booster.shell

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.withContext
import java.util.concurrent.TimeUnit

data class ShellResult(val exitCode: Int, val output: String) {
    val ok: Boolean get() = exitCode == 0
}

object ShellExecutor {
    /** Uses Shizuku (shell uid) when granted, otherwise the app's own uid. */
    suspend fun run(command: String, timeoutMs: Long = 8_000L): ShellResult = withContext(Dispatchers.IO) {
        val process = try {
            (if (ShizukuHelper.hasPermission()) runCatching { ShizukuHelper.newShizukuProcess(command) }.getOrNull() else null)
                ?: ProcessBuilder("sh", "-c", command).redirectErrorStream(true).start()
        } catch (e: Exception) {
            return@withContext ShellResult(-1, e.message.orEmpty())
        }
        val reader = async { process.inputStream.bufferedReader().use { it.readText() } }
        if (!process.waitFor(timeoutMs, TimeUnit.MILLISECONDS)) {
            process.destroy()
            reader.cancel()
            return@withContext ShellResult(-1, "timeout")
        }
        ShellResult(process.exitValue(), reader.await().trim())
    }

    suspend fun runLogged(command: String, label: String, notes: MutableList<String>) {
        val r = run(command)
        notes += (if (r.ok) "✓ " else "✗ ") + label
    }
}
