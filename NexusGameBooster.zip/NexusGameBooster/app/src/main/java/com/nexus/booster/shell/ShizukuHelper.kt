package com.nexus.booster.shell

import android.content.pm.PackageManager
import rikka.shizuku.Shizuku

object ShizukuHelper {
    const val REQUEST_CODE = 1001

    fun isBinderAlive(): Boolean = try { Shizuku.pingBinder() } catch (_: Throwable) { false }

    fun hasPermission(): Boolean = try {
        isBinderAlive() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (_: Throwable) { false }

    fun requestPermission() {
        if (isBinderAlive() && !hasPermission()) Shizuku.requestPermission(REQUEST_CODE)
    }

    /**
     * Shizuku 13.x keeps newProcess() private, so we reach it via reflection.
     * The process runs as the shell user (uid 2000), which is what grants us
     * WRITE_SECURE_SETTINGS, `cmd appops`, `cmd deviceidle`, `am force-stop`, etc.
     */
    fun newShizukuProcess(command: String): Process {
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
        )
        m.isAccessible = true
        return m.invoke(null, arrayOf("sh", "-c", command), null, null) as Process
    }
}
