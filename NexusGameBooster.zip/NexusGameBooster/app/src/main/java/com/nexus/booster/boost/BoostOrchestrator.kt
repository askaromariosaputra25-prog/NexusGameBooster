package com.nexus.booster.boost

import android.content.Context

data class BoostReport(
    val game: GameTarget,
    val freedMb: Long,
    val mode: String,
    val pingBefore: Double?,
    val pingAfter: Double?,
    val notes: List<String>,
)

object BoostOrchestrator {
    suspend fun boostAndPrepare(
        ctx: Context,
        game: GameTarget,
        installed: List<String>,
        onStep: (String) -> Unit,
    ): BoostReport {
        onStep("OPTIMIZING...")
        onStep("CLEANING JUNK...")
        val clean = PreLaunchCleaner.clean(ctx)
        onStep("LOCKING CPU...")
        val lockNotes = CpuRamLocker.lock(installed)
        onStep("BOOSTING NETWORK...")
        val net = PingBooster.boost(game.serverHost)
        onStep("READY!")
        return BoostReport(game, clean.freedMb, clean.mode, net.before, net.after, lockNotes + net.notes)
    }
}
