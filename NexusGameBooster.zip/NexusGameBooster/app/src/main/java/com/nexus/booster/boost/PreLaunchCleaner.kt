package com.nexus.booster.boost

import android.app.ActivityManager
import android.content.Context
import android.content.pm.ApplicationInfo
import com.nexus.booster.shell.ShellExecutor
import com.nexus.booster.shell.ShizukuHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

object PreLaunchCleaner {
    data class Result(val killed: Int, val freedMb: Long, val mode: String)

    // Never touched: OEM/system/keyboard families, our own app, and all supported games.
    private val PROTECTED_PREFIXES = listOf(
        "com.android", "com.google", "com.samsung", "com.miui", "com.xiaomi", "com.coloros",
        "com.oppo", "com.realme", "com.vivo", "com.transsion", "com.infinix", "com.itel",
        "com.mediatek", "com.qualcomm", "rikka.shizuku", "moe.shizuku", "com.nexus.booster",
    )
    private val ALL_GAMES = GameTarget.entries.flatMap { it.packages }

    fun memAvailMb(ctx: Context): Long {
        val mi = ActivityManager.MemoryInfo()
        ctx.getSystemService(ActivityManager::class.java).getMemoryInfo(mi)
        return mi.availMem / 1_048_576L
    }

    suspend fun clean(ctx: Context): Result = withContext(Dispatchers.IO) {
        val before = memAvailMb(ctx)
        val targets = listThirdParty(ctx).filter { pkg ->
            pkg !in ALL_GAMES && PROTECTED_PREFIXES.none { pkg.startsWith(it) }
        }
        val base = if (ShizukuHelper.hasPermission()) {
            ShellExecutor.run(targets.joinToString(";") { "am force-stop $it" }, 20_000)
            Result(targets.size, 0, "Shizuku (force-stop)")
        } else {
            val am = ctx.getSystemService(ActivityManager::class.java)
            targets.forEach { am.killBackgroundProcesses(it) }
            Result(targets.size, 0, "Normal (killBackgroundProcesses)")
        }
        delay(800) // give the system a moment to reclaim memory
        base.copy(freedMb = (memAvailMb(ctx) - before).coerceAtLeast(0))
    }

    private suspend fun listThirdParty(ctx: Context): List<String> =
        if (ShizukuHelper.hasPermission()) {
            ShellExecutor.run("pm list packages -3").output.lines()
                .map { it.removePrefix("package:").trim() }
                .filter { it.isNotEmpty() && ' ' !in it }
        } else {
            ctx.packageManager.getInstalledApplications(0)
                .filter { it.flags and ApplicationInfo.FLAG_SYSTEM == 0 }
                .map { it.packageName }
        }
}
