package com.nexus.booster.oem

import android.app.AppOpsManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Process
import android.provider.Settings

object OemAutoStartHelper {
    private val OEM_SECURITY_APP = mapOf(
        "xiaomi" to "com.miui.securitycenter",
        "redmi" to "com.miui.securitycenter",
        "oppo" to "com.coloros.safecenter",
        "realme" to "com.coloros.safecenter",
        "vivo" to "com.vivo.permissionmanager",
        "samsung" to "com.samsung.android.lool",
    )

    /** Opens the OEM security/autostart screen; falls back to this app's settings page. */
    fun openAutoStart(ctx: Context) {
        val pkg = OEM_SECURITY_APP[Build.MANUFACTURER.lowercase()] ?: OEM_SECURITY_APP[Build.BRAND.lowercase()]
        val intent = pkg?.let { ctx.packageManager.getLaunchIntentForPackage(it) }
            ?: Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}"))
        try {
            ctx.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) {
            ctx.startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }
    }

    @Suppress("DEPRECATION")
    fun hasUsageAccess(ctx: Context): Boolean {
        val ops = ctx.getSystemService(AppOpsManager::class.java)
        val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
        } else {
            ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
        }
        return mode == AppOpsManager.MODE_ALLOWED
    }

    fun usageAccessIntent(): Intent = Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)

    fun overlayIntent(ctx: Context): Intent =
        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}"))
}
