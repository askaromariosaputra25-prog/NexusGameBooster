package com.nexus.booster.boost

enum class GameTarget(
    val title: String,
    val packages: List<String>,
    /** Host used for latency checks. PUBG host is approximate; adjust if your region differs. */
    val serverHost: String,
    val accentArgb: Int,
) {
    MLBB("Mobile Legends: Bang Bang", listOf("com.mobile.legends"), "sg.mobilelegends.com", 0xFFFFD700.toInt()),
    FREE_FIRE("Free Fire", listOf("com.dts.freefireth", "com.dts.freefiremax"), "ff.garena.com", 0xFFE53935.toInt()),
    PUBG("PUBG Mobile", listOf("com.tencent.ig", "com.pubg.imobile"), "gcloud.qq.com", 0xFF1E88E5.toInt());
}
