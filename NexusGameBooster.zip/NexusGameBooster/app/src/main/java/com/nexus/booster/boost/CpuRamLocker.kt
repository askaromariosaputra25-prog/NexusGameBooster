package com.nexus.booster.boost

import com.nexus.booster.shell.ShellExecutor
import com.nexus.booster.shell.ShizukuHelper

object CpuRamLocker {
    /** Requires Shizuku. Returns a human-readable log of each step. */
    suspend fun lock(installedPkgs: List<String>): List<String> {
        if (!ShizukuHelper.hasPermission()) return listOf("✗ CPU/RAM lock butuh Shizuku aktif")
        val notes = mutableListOf<String>()
        installedPkgs.forEach { pkg ->
            ShellExecutor.runLogged("cmd appops set $pkg RUN_IN_BACKGROUND allow", "Background diizinkan: $pkg", notes)
            ShellExecutor.runLogged("cmd deviceidle whitelist +$pkg", "Doze whitelist: $pkg", notes)
        }
        ShellExecutor.runLogged(
            "settings put global sem_enhanced_cpu_responsiveness 1",
            "CPU responsiveness (Samsung)", notes,
        )
        ShellExecutor.runLogged(
            "sync; echo 3 > /proc/sys/vm/drop_caches",
            "Drop caches (butuh root, di non-root biasanya gagal)", notes,
        )
        return notes
    }
}
