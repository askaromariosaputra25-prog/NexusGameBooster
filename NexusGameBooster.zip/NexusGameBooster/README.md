# NEXUS GAME BOOSTER v1 (MLBB • Free Fire • PUBG)

Booster khusus 3 game. Tanpa root. Butuh **Shizuku** untuk fitur penuh.

## Build di GitHub (paling gampang)
1. Buat repo baru di GitHub (misal `nexus-game-booster`).
2. Ekstrak zip ini, lalu upload **isi** folder `NexusGameBooster/` ke root repo
   (`settings.gradle.kts` harus ada di root repo).
   Atau lewat terminal:
   ```bash
   cd NexusGameBooster
   git init && git add . && git commit -m "v1"
   git branch -M main
   git remote add origin https://github.com/USERNAME/nexus-game-booster.git
   git push -u origin main
   ```
3. Buka tab **Actions** di repo. Workflow **Android CI** jalan otomatis.
   Kalau belum, klik workflow lalu **Run workflow**.
4. Setelah hijau, buka run tersebut, lalu download artifact `NexusGameBooster-debug`.
5. Di HP: izinkan "Install dari sumber tidak dikenal", lalu install APK.

## Build lokal (Android Studio)
1. Buka folder project di Android Studio (Ladybug / Koala atau lebih baru).
2. Android Studio otomatis membuat Gradle wrapper saat sync.
3. Menu **Build → Build APK(s)**.

## Setup Shizuku (wajib untuk fitur penuh)
1. Install **Shizuku** dari Play Store / GitHub.
2. Aktifkan lewat **Wireless debugging** (Android 11+), atau via ADB sekali.
3. Buka Shizuku → **Start**.
4. Buka NEXUS → tekan **Aktifkan** di status Shizuku → izinkan.

Tanpa Shizuku: app tetap jalan, tapi cuma bisa clean RAM standar. Tweak jaringan, CPU, dan FPS tidak aktif.

## Batasan jujur
- `drop_caches` butuh root. Shizuku tidak bisa menulis ke sana, jadi langkah ini pasti dilaporkan gagal.
- "Bebas 600 MB" tidak dijamin. App menampilkan jumlah RAM yang benar-benar terbebas.
- Ping ke server game: pakai ICMP. Kalau diblokir, pakai TCP connect time sebagai fallback.
- FPS per-game dibaca dari `dumpsys gfxinfo` (butuh Shizuku). Tanpa Shizuku, FPS tampil "butuh Shizuku".
- Key seperti `wifi_low_latency` dan `sem_enhanced_cpu_responsiveness` tergantung ROM. Hasilnya dicatat sebagai ✓/✗ di layar hasil.
- Host server PUBG (`gcloud.qq.com`) adalah perkiraan. Ganti di `GameTarget.kt` jika perlu.
- Belum ada di v1: Hilt, Room, DataStore, dan animasi Lottie. Akan ditambahkan di v2 setelah build v1 stabil.
- Belum diuji di perangkat nyata. Test di Infinix, Oppo A5/A57, dan Redmi tetap diperlukan.
